# wxTest
---
表头|表头|表头
---|:--:|---:
内容|内容|内容
内容|内容|内容
---
测试代码块<br>
```
    function fun(){
         echo "代码块测试语句";
    }
    fun();
```

```flow
st=>start: 开始
op=>operation: My Operation
cond=>condition: Yes or No?
e=>end
st->op->cond
cond(yes)->e
cond(no)->op
&```
